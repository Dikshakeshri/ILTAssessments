package LiskovSubstitutionPrinciple;

public class MotorBike implements Car {
 
   
 
    //Constructors, getters + setters
 
    public void turnEngine() {
        //turn on the engine!
       System.out.println("turn engine on and go slow!!");
    }
 
    public void acceleration() {
        //move forward!
        System.out.println("Move forward and maintain speed");
    }
}