package LiskovSubstitutionPrinciple;

public class Vehicle {
public static void main(String[] args) {
	MotorBike m=new MotorBike();
	System.out.println("Motor bike");
	m.turnEngine();
	m.acceleration();
	
	
	System.out.println("Electric bike");
	ElectricBike e=new ElectricBike();
	
		//e.turnEngine();
	
	
	e.acceleration();
}
}
