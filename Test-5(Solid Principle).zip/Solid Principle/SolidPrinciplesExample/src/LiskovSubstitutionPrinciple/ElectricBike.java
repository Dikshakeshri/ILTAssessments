package LiskovSubstitutionPrinciple;

public class ElectricBike  implements Car {
 
    public void turnEngine() {
        throw new AssertionError("No engine to move!");
    }
 
    public void acceleration() {
        //this acceleration is crazy!
    	System.out.println("accelerate!\n Move Forward");
    }
}