package LiskovSubstitutionPrinciple;

public interface Bike {

	void turnEngine();
    void acceleration();
}