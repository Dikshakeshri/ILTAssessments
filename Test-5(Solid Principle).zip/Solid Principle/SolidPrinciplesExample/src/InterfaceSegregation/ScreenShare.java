package InterfaceSegregation;

public interface ScreenShare {
public void shareScreen();
}
