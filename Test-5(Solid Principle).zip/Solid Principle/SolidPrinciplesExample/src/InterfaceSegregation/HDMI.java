package InterfaceSegregation;

public interface HDMI {
public void HDMI();

}
