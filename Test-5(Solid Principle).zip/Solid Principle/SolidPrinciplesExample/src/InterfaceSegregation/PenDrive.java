package InterfaceSegregation;

public interface PenDrive {
public void PenDrive();

}
