package InterfaceSegregation;

public class SonyService implements HDMI,PenDrive,ScreenShare{

	@Override
	public void PenDrive() {
		// TODO Auto-generated method stub
		System.out.println("PenDrive");
	}

	@Override
	public void HDMI() {
		// TODO Auto-generated method stub
		System.out.println("HDMI");
	}

	@Override
	public void shareScreen() {
		// TODO Auto-generated method stub
		System.out.println("ShareScreen");
	}

}
