package InterfaceSegregation;

public class Service {
	public static void main(String[] args) {
		SonyService s=new SonyService();
		System.out.println("SonyService supports following features");
s.PenDrive();
s.HDMI();
s.shareScreen();
System.out.println("Videocon supports following features");

VideoconService v=new VideoconService();
v.HDMI();
v.PenDrive();
		}
}