package OpenClosedPrinciple;

import java.util.Scanner;

public class Cir implements ShapePoly
{
public double r;
public double calcArea()
{
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter radius");
	radius=sc.nextDouble();
return (22/7)*radius*radius;
}
}