package OpenClosedPrinciple;

import java.util.Scanner;

public class CalcArea {
	
	
	public static void main(String[] args) {
		
		ShapePoly shape;
		Scanner sc = new Scanner(System.in);
		System.out.println("Calculate Area of \n1.Circle\n2.Rectangle");
		System.out.println("Enter ur choice");
		String s=sc.next();
		if(s.equalsIgnoreCase("cir")){
			 shape=new Cir();
		System.out.print("Area="+shape.calcArea());
		}
		
		
		else if(s.equalsIgnoreCase("Rect"))
		{
			shape=new Rect();
			System.out.print("Area="+shape.calcArea());
		}

			
		else 
			System.out.println("Invalid input");
		
		
	}
}
