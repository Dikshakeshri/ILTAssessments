package OpenClosedPrinciple;

import java.util.Scanner;

public class Rect implements ShapePoly
{
int l;
int b;
public double calcArea()
{
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter length and width");
l=sc.nextInt();
b=sc.nextInt();
return l * b;
}
}