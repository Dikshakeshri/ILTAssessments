package OpenClosedPrinciple;

public interface ShapePoly {
	public double calculateArea();
}
