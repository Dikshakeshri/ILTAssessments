package DependencyInversion;

public class DataFactory {
	public static ICustData GetCustDataAccessObj() 
{
    return new CustData();
}
}