package DependencyInversion;

public class Customer {
	public static void main(String[] args) {
		

CustData c=new CustData();
String name=c.GetCustName(1);
System.out.println(name);
}
}
