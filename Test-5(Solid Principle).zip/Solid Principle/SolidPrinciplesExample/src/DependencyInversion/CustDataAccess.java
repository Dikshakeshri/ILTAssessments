package DependencyInversion;

public class CustDataAccess implements ICustData
{
    public CustData() {
    }

    public String GetCustName(int id) {
        return "Dummy Customer Name";        
    }
}