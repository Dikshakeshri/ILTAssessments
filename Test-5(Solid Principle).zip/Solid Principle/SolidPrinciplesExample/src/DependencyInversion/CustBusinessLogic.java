package DependencyInversion;

public class CustBusinessLogic
{
	ICustData _custData;

public CustBusinessLogic()
{
    _custData = DataAccessFactory.GetCustDataAccessObj();
}

public String GetCustName(int id)
{
    return _custData.GetCustName(id);
}
}

