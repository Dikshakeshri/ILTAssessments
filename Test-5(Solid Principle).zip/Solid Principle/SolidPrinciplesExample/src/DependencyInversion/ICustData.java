package DependencyInversion;

public interface ICustData {
	String GetCustName(int id);
}
