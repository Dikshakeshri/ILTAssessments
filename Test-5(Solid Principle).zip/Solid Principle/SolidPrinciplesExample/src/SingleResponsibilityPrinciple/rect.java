package SingleResponsibilityPrinciple;

public class rect {
	//A class should have only one responsibility
double calcArea(int l,int b){
	return (l*b);
}
}
