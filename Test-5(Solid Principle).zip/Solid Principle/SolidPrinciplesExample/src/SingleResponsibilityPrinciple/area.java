package SingleResponsibilityPrinciple;

import java.util.Scanner;

public class area {
public static void main(String[] args) {
	int l,b;
	Scanner sc=new Scanner(System.in);
	System.out.println("enter length and breadth to calculate area");
	l=sc.nextInt();
	b=sc.nextInt();
	rect r=new rect();
	System.out.print("Area is"+r.calcArea(l,b));
	sc.close();
	
	
	
}

}
