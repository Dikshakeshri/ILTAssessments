package com.nttdata;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Client {

	public static void main(String[] args) {
		Configuration cfg=new Configuration();
		cfg.configure("HibernateConfig.xml");
		
		SessionFactory fc=cfg.buildSessionFactory();
		Session session=fc.openSession();
		
		Product product=new Product();
		product.setProductId(101);
		product.setProductName("Mobile");
		
		Category c1=new Category();
		c1.setCategoryId(21);
		c1.setCategoryName("Redmi");
		
		Category c2=new Category();
		c2.setCategoryId(22);
		c2.setCategoryName("OPPO");
		
		Category c3=new Category();
		c3.setCategoryId(23);
		c3.setCategoryName("VIVO");
		
		Category c4=new Category();
		c4.setCategoryId(24);
		c4.setCategoryName("Samsung");
		
		Set s=new HashSet<>();
		s.add(c1);
		s.add(c2);
		s.add(c3);
		s.add(c4);
		
		product.setChildrens(s);
		
		Transaction tx=session.beginTransaction();
		session.save(product);
		tx.commit();
		System.out.println("one to many mapping is inserted");
		session.close();
		fc.close();
		
		

	}

}
