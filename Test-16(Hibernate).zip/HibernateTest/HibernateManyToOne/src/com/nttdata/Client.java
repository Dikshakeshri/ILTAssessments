package com.nttdata;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Client {

	public static void main(String[] args) {
		Configuration cfg=new Configuration();
		cfg.configure("HibernateConfig.xml");
		
		SessionFactory fc=cfg.buildSessionFactory();
		Session session=fc.openSession();
		
		Product product=new Product();
		product.setProductId(101);
		product.setProductName("Mobile");
		
		Category c1=new Category();
		c1.setCategoryId(21);
		c1.setCategoryName("Redmi");
		c1.setProduct(product);
		
		Category c2=new Category();
		c2.setCategoryId(22);
		c2.setCategoryName("OPPO");
		c2.setProduct(product);
		
		Category c3=new Category();
		c3.setCategoryId(23);
		c3.setCategoryName("VIVO");
		c3.setProduct(product);
		
		Category c4=new Category();
		c4.setCategoryId(24);
		c4.setCategoryName("Samsung");
		c4.setProduct(product);
		
		
		
		Transaction tx=session.beginTransaction();
		
		session.save(c1);
		session.save(c2);
		session.save(c3);
		session.save(c4);
		tx.commit();
		System.out.println("Many to one mapping is inserted");
		session.close();
		fc.close();

	}

}
