package com.nttdata;

public class Bank {

	void transferFunds(User u1,User u2,double amount) throws InsufficientAmount
	{
		if(u1.getAcc().getAmount()<amount)
		{
			throw new InsufficientAmount("you have insufficient balance in your account!!!,please check");
		}
		else
		{
		double u1amt=	u1.getAcc().getAmount();
		double	amt1=u1amt-amount;
		u1.getAcc().setAmount(amt1);
		double u2amt=	u2.getAcc().getAmount();
		double	amt2=u2amt+amount;
		u2.getAcc().setAmount(amt2);
		}
		
	}
	
	
	
}
