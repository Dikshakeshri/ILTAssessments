package Employee;

import java.util.ArrayList;

public class EmpDetailsMain {


	
	public static void main(String[] args) {
	
		
		Emp em1=new Emp(101,"Diksha","banglalore",55000,"5th grade",876645322,"diksha@gmail.com");
		Emp em2=new Emp(102,"Spoorthi","bangalore",23400,"6th grade",3556722,"spoorthi@gmail.com");				
	     	Emp em3=new Emp(103,"Anusha","chennai",23400,"6th grade",3556722,"anusha@gmail.com");	
		
		ArrayList<Emp> list = new ArrayList<Emp>();

	     // Adding elements to the LinkedList
	     list.add(em1);
	     list.add(em2);
	     list.add(em3);
	     
	     
	   for( Emp e: list)
	     System.out.println("Employee Details "+e);
	  }
	}

	
