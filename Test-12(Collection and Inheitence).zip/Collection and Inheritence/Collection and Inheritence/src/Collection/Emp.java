package Employee;

public class Emp {

	private int empId;
	private String name;
	private String	address;
	private int salary;
	private String	grade;
	private int mobileno;
	private String email;
	public Emp(int empId, String name, String address, int salary, String grade, int mobileno, String email) {
		super();
		this.empId = empId;
		this.name = name;
		this.address = address;
		this.salary = salary;
		this.grade = grade;
		this.mobileno = mobileno;
		this.email = email;
	}
	@Override
	public String toString() {
		return "Emp [empId=" + empId + ", name=" + name + ", address=" + address + ", salary=" + salary + ", grade="
				+ grade + ", mobileno=" + mobileno + ", email=" + email + "]";
	}
	
	
	
}