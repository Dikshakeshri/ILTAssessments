package com.nttdata.EmployeeTest;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.mockito.Mockito;

import com.nttdata.Dao.EmployeeDao;
import com.nttdata.Model.Employee;

public class EmployeeTestUsingMokito {

	EmployeeDao employeeDao=Mockito.mock(EmployeeDao.class);
	@Test
	public void testListEmployee()
	{
		List<Employee> list=new ArrayList<>();
		
		list.add(new Employee(101,"Radha","Bangalore"));
		list.add(new Employee(102,"Raghav","Delhi"));
		list.add(new Employee(103,"Ravi","Mumbai"));
		list.add(new Employee(104,"Rashi","Kolkata"));
		list.add(new Employee(105,"Rohit","Jaipur"));
		list.add(new Employee(106,"Rakhi","Patna"));
		
		Mockito.when(employeeDao.list()).thenReturn(list);
		
	}
	@Test
	public void testCreateEmployee()
	{
		Employee employee=new Employee(107,"Rishav","Rachi");
		Mockito.when(employeeDao.createEmployee()).thenReturn(employee);
	}
	@Test
	public void testDeleteEmployee()
	{
		
		Employee employee=new Employee(107,"Rishav","Rachi");
		Mockito.when(employeeDao.deleteEmployee(107)).thenReturn(employee);
	}
	@Test
	public void testgetByEmployeeId()
	{
		Employee employee=new Employee(107,"Rishav","Rachi");
		Mockito.when(employeeDao.getByEmployeeID(107)).thenReturn(employee);
	}
	@Test
	public void testsearchEmployeeByName()
	{
		Employee employee=new Employee(103,"Ravi","Mumbai");
		Mockito.when(employeeDao.searchEmployeeByName("Ravi")).thenReturn(employee);
	}
}
