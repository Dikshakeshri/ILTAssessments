package com.nttdata;



import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Client {

	public static void main(String[] args) {
		Resource res=new ClassPathResource("Spring.xml");
		BeanFactory factory=new XmlBeanFactory(res);
		Object o=factory.getBean("id1");
		Object o1=factory.getBean("id2");
		Book b=(Book)o;
		b.setBookName("Dream");
		b.setBookPrice(200);
		Categories c1=(Categories)o1;
		
		c1.setName("Mystery");
		c1.setBook(b);
		c1.display();

	}

}
