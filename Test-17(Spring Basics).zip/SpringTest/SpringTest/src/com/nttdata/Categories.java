package com.nttdata;

public class Categories {
	private Book book;
	private String name;
	public Book getBook() {
		return book;
	}
	public void setBook(Book book) {
		this.book = book;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void display()
	{
		book.display();
		System.out.println("Caterory :"+name);
		
	}
}
