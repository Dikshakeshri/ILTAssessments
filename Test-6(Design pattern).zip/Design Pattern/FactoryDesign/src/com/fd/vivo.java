package com.fd;

public class vivo extends Mobile{

	@Override
	public double getTax() {
		return 7;
		
	}

}
