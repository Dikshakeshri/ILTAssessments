package com.fd;

public class oppo extends Mobile{

	@Override
	public double getTax() {
		return 14;		
	}

}
