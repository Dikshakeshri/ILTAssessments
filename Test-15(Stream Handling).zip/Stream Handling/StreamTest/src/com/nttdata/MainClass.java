package com.nttdata;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class MainClass {

	public static void main(String[] args) {
		List<Employee> employeeList=new ArrayList<>();
		List<Float> employeeListPrice=new ArrayList<>();
		employeeList.add(new Employee(1,"saumya",30000));
		employeeList.add(new Employee(2,"Dristi",5000));
		employeeList.add(new Employee(3,"Rashi",20000));
		employeeList.add(new Employee(4,"Naina",4000));
		employeeList.add(new Employee(5,"Rajesh",50000));
		employeeList.add(new Employee(6,"Saurabh",60000));
		employeeList.add(new Employee(7,"Manish",7000));
		
		employeeListPrice=employeeList.stream().filter(p->p.price>10000).map(p->p.price).collect(Collectors.toList());
		System.out.println("Salary of employee greater than 10000: "+employeeListPrice);
		long g =employeeListPrice.stream().collect(Collectors.counting());
		System.out.println("Number of employee having salary greater than 10000: "+g);
		
	}

}
